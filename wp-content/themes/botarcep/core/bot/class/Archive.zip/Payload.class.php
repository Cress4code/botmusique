<?php

class Payload {

    public $url;

    public function __construct($url) {
        $this->url = $url;
    } // __construct

} // Payload
