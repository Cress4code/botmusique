<?php

class Template {

    public $template_type;

} // Template
